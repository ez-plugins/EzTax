package com.skyblockexp.eztax.bootstrap;

import com.skyblockexp.eztax.EzTaxPlugin;
import com.skyblockexp.eztax.bootstrap.component.*;

public class PluginBootstrap {
    private final EzTaxPlugin plugin;

    // components
    private ConfigComponent configComponent;
    private MetricsComponent metricsComponent;
    private EconomyComponent economyComponent;
    private StatsComponent statsComponent;
    private ExemptionComponent exemptionComponent;
    private TaxEngineComponent taxEngineComponent;
    private SchedulerComponent schedulerComponent;
    private CommandComponent commandComponent;
    private ListenerComponent listenerComponent;

    public PluginBootstrap(EzTaxPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        // create components in order
        configComponent = new ConfigComponent(plugin);
        configComponent.start();

        metricsComponent = new MetricsComponent(plugin);
        metricsComponent.start();

        statsComponent = new StatsComponent(plugin, configComponent.getTaxConfig());
        statsComponent.start();

        exemptionComponent = new ExemptionComponent(plugin);
        exemptionComponent.start();

        economyComponent = new EconomyComponent(plugin, configComponent.getTaxConfig());
        economyComponent.start();

        if (economyComponent.isHooked()) {
            taxEngineComponent = new TaxEngineComponent(plugin, configComponent.getTaxConfig(), statsComponent.getStatsService(), exemptionComponent.getExemptionService(), economyComponent.getVaultHook());
            taxEngineComponent.start();

            economyComponent.registerTaxEngine(taxEngineComponent.getTaxEngine());

            listenerComponent = new ListenerComponent(plugin, configComponent.getTaxConfig(), taxEngineComponent.getTaxEngine());
            listenerComponent.start();

            schedulerComponent = new SchedulerComponent(plugin, configComponent.getTaxConfig(), taxEngineComponent.getTaxEngine());
            schedulerComponent.start();
        } else {
            plugin.getLogger().warning("Vault economy was not detected. EzTax will run in standby mode.");
        }

        commandComponent = new CommandComponent(plugin, configComponent.getTaxConfig(), statsComponent.getStatsService(), taxEngineComponent != null ? taxEngineComponent.getTaxEngine() : null, economyComponent.getVaultHook(), configComponent.getMessages(), exemptionComponent.getExemptionService());
        commandComponent.start();
    }

    public void stop() {
        if (schedulerComponent != null) schedulerComponent.stop();
        if (listenerComponent != null) listenerComponent.stop();
        if (taxEngineComponent != null) taxEngineComponent.stop();
        if (economyComponent != null) economyComponent.stop();
        if (exemptionComponent != null) exemptionComponent.stop();
        if (statsComponent != null) statsComponent.stop();
        if (metricsComponent != null) metricsComponent.stop();
        if (configComponent != null) configComponent.stop();
        if (commandComponent != null) commandComponent.stop();
    }

    public void reload() {
        // naive reload: stop then start
        stop();
        start();
    }

    // getters for components (useful for tests)
    public ConfigComponent getConfigComponent() { return configComponent; }
    public StatsComponent getStatsComponent() { return statsComponent; }
    public EconomyComponent getEconomyComponent() { return economyComponent; }
    public TaxEngineComponent getTaxEngineComponent() { return taxEngineComponent; }
    public ExemptionComponent getExemptionComponent() { return exemptionComponent; }
}
