package com.skyblockexp.eztax.bootstrap.component;

import com.skyblockexp.eztax.bootstrap.Component;
import com.skyblockexp.eztax.EzTaxPlugin;
import org.bstats.bukkit.Metrics;

public class MetricsComponent implements Component {
    private final EzTaxPlugin plugin;
    private Metrics metrics;

    public MetricsComponent(EzTaxPlugin plugin) { this.plugin = plugin; }

    @Override
    public void start() {
        this.metrics = new Metrics(plugin, 28537);
    }

    @Override
    public void stop() {
        // bStats has no stop API
    }

    @Override
    public void reload() {
        // nothing
    }
}
