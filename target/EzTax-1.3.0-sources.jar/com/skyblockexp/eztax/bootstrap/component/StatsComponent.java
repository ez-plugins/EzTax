package com.skyblockexp.eztax.bootstrap.component;

import com.skyblockexp.eztax.bootstrap.Component;
import com.skyblockexp.eztax.EzTaxPlugin;
import com.skyblockexp.eztax.service.StatsService;
import com.skyblockexp.eztax.config.TaxConfig;

public class StatsComponent implements Component {
    private final EzTaxPlugin plugin;
    private final TaxConfig taxConfig;
    private StatsService statsService;

    public StatsComponent(EzTaxPlugin plugin, TaxConfig taxConfig) {
        this.plugin = plugin;
        this.taxConfig = taxConfig;
    }

    @Override
    public void start() {
        this.statsService = new StatsService(plugin, taxConfig);
    }

    @Override
    public void stop() {
        if (statsService != null) statsService.save();
    }

    @Override
    public void reload() {
        // nothing
    }

    public StatsService getStatsService() { return statsService; }
}
