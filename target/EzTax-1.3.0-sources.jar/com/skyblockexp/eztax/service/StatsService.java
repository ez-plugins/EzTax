package com.skyblockexp.eztax.service;

import com.skyblockexp.eztax.config.TaxConfig;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.EnumMap;
import java.util.Map;
import java.util.logging.Level;

public class StatsService {
    private final JavaPlugin plugin;
    private final TaxConfig config;
    private final File statsFile;

    private final Map<TaxSink, Double> sinkTotals = new EnumMap<>(TaxSink.class);
    private double totalRemoved;
    private double dailyRemoved;
    private double weeklyRemoved;
    private double treasuryBalance;
    private LocalDate dailyResetDate;
    private LocalDate weeklyResetDate;

    public StatsService(JavaPlugin plugin, TaxConfig config) {
        this.plugin = plugin;
        this.config = config;
        this.statsFile = new File(plugin.getDataFolder(), "stats.yml");
        load();
    }

    public void reload() {
        load();
    }

    public synchronized void recordTax(TaxSink sink, double amount) {
        recordTax(sink, amount, config.isTreasuryEnabled());
    }

    public synchronized void recordTax(TaxSink sink, double amount, boolean addToTreasury) {
        if (amount <= 0) {
            return;
        }
        ensureResets();
        totalRemoved += amount;
        dailyRemoved += amount;
        weeklyRemoved += amount;
        sinkTotals.put(sink, sinkTotals.getOrDefault(sink, 0.0D) + amount);
        if (addToTreasury) {
            treasuryBalance += amount;
        }
        save();
    }

    public synchronized double getTotalRemoved() {
        return totalRemoved;
    }

    public synchronized double getDailyRemoved() {
        ensureResets();
        return dailyRemoved;
    }

    public synchronized double getWeeklyRemoved() {
        ensureResets();
        return weeklyRemoved;
    }

    public synchronized double getTreasuryBalance() {
        return treasuryBalance;
    }

    public synchronized Map<TaxSink, Double> getSinkTotals() {
        return new EnumMap<>(sinkTotals);
    }

    public synchronized void save() {
        FileConfiguration config = new YamlConfiguration();
        config.set("totals.overall", totalRemoved);
        config.set("totals.daily", dailyRemoved);
        config.set("totals.weekly", weeklyRemoved);
        config.set("totals.treasury", treasuryBalance);
        for (Map.Entry<TaxSink, Double> entry : sinkTotals.entrySet()) {
            config.set("totals.sinks." + entry.getKey().name(), entry.getValue());
        }
        config.set("resets.daily", dailyResetDate != null ? dailyResetDate.toString() : null);
        config.set("resets.weekly", weeklyResetDate != null ? weeklyResetDate.toString() : null);
        try {
            config.save(statsFile);
        } catch (IOException exception) {
            plugin.getLogger().log(Level.WARNING, "Failed to save EzTax stats file.", exception);
        }
    }

    private void load() {
        if (!statsFile.exists()) {
            plugin.getDataFolder().mkdirs();
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(statsFile);
        totalRemoved = config.getDouble("totals.overall", 0.0D);
        dailyRemoved = config.getDouble("totals.daily", 0.0D);
        weeklyRemoved = config.getDouble("totals.weekly", 0.0D);
        treasuryBalance = config.getDouble("totals.treasury", 0.0D);
        sinkTotals.clear();
        for (TaxSink sink : TaxSink.values()) {
            sinkTotals.put(sink, config.getDouble("totals.sinks." + sink.name(), 0.0D));
        }
        dailyResetDate = parseDate(config.getString("resets.daily"));
        weeklyResetDate = parseDate(config.getString("resets.weekly"));
        ensureResets();
        save();
    }

    private LocalDate parseDate(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(value);
        } catch (Exception ignored) {
            return null;
        }
    }

    private void ensureResets() {
        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        if (dailyResetDate == null || !dailyResetDate.equals(today)) {
            dailyResetDate = today;
            dailyRemoved = 0.0D;
        }
        LocalDate weekStart = today.with(DayOfWeek.MONDAY);
        if (weeklyResetDate == null || !weeklyResetDate.equals(weekStart)) {
            weeklyResetDate = weekStart;
            weeklyRemoved = 0.0D;
        }
    }
}
